(function(){var a;a=$(document),a.bind("mobileinit",function(a){return _.extend($.mobile,{ajaxEnabled:!1,linkBindingEnabled:!1,hashListeningEnabled:!1,pushStateEnabled:!1})})}).call(this)
